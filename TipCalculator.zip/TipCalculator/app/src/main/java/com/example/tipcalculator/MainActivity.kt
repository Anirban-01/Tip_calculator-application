package com.example.tipcalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tipcalculator.databinding.ActivityMainBinding
import java.text.NumberFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.button.setOnClickListener {
            calculate_tip()
        }
    }

    private fun calculate_tip(){
        //taking input from edit field and adding .text means taking property of edittext object
        val get_text = binding.EditText.text.toString()
        // creating variable to get text from variable get_text and convert to double
        val cost = get_text.toDouble()
        //when radio button is checked
        val tip_percent = when(binding.radioGroup.checkedRadioButtonId){
            R.id.radioButton1 -> 0.20
            R.id.radioButton2 -> 0.18
            else -> 0.15
        }

        var tip = tip_percent * cost
        // to do round of tip amount
        if (binding.switch1.isChecked){
            tip = kotlin.math.ceil(tip)
        }
        //to get currency
        val tip_currency = NumberFormat.getCurrencyInstance(Locale("en", "IN")).format(tip)
        binding.textView2.text = getString(R.string.text8, tip_currency)

    }
}


